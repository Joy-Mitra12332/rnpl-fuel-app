// RNPL Fuel Inventory App - backend. Paste into Extensions > Apps Script of the coal sheet.
const TZ = 'Asia/Dhaka', SESSION_DAYS = 30;
const USERS_TAB = 'Users';                       // column A = email, column B = name (optional)
const props = PropertiesService.getScriptProperties();
const cache = CacheService.getScriptCache();

function authorize() { SpreadsheetApp.getActiveSpreadsheet().getName(); MailApp.getRemainingDailyQuota(); }

function out(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
const norm = s => String(s || '').trim().toLowerCase();
const num = s => { const n = parseFloat(String(s).replace(/,/g, '')); return isNaN(n) ? 0 : n; };

function doGet(e) {
  const p = e.parameter || {};
  try {
    if (p.action === 'request') return out(requestCode(norm(p.email)));
    if (p.action === 'verify') return out(verify(norm(p.email), String(p.code || '').trim()));
    if (p.action === 'data') {
      const em = session(p.token);
      if (!em) return out({ ok: false, auth: false });
      return out({ ok: true, user: em, data: buildData() });
    }
    return out({ ok: false });
  } catch (err) { return out({ ok: false, error: String(err) }); }
}

function allowed(email) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(USERS_TAB);
  if (!sh || !email) return false;
  return sh.getRange(1, 1, Math.max(sh.getLastRow(), 1), 1).getValues().some(r => norm(r[0]) === email);
}

function requestCode(email) {
  const res = { ok: true, msg: 'If this email is authorised, a code has been sent.' };
  if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, msg: 'Enter a valid email address.' };
  if (cache.get('rq:' + email)) return res;            // 1 request per minute per email
  cache.put('rq:' + email, '1', 60);
  if (!allowed(email)) return res;                     // same reply either way
  const code = String(100000 + parseInt(Utilities.getUuid().replace(/-/g, '').slice(0, 8), 16) % 900000);
  cache.put('otp:' + email, code, 600);
  cache.remove('try:' + email);
  MailApp.sendEmail(email, 'RNPL Fuel App sign-in code', 'Your sign-in code is ' + code + '\nIt is valid for 10 minutes. Do not share it.');
  return res;
}

function verify(email, code) {
  const tries = Number(cache.get('try:' + email)) || 0;
  if (tries >= 5) return { ok: false, msg: 'Too many attempts. Request a new code.' };
  const real = cache.get('otp:' + email);
  if (!real || real !== code || !allowed(email)) {
    cache.put('try:' + email, String(tries + 1), 600);
    return { ok: false, msg: 'Wrong or expired code.' };
  }
  cache.remove('otp:' + email);
  const token = Utilities.getUuid() + Utilities.getUuid();
  props.setProperty('s:' + token, email + '|' + (Date.now() + SESSION_DAYS * 864e5));
  return { ok: true, token: token };
}

function session(token) {
  if (!token) return null;
  const v = props.getProperty('s:' + token);
  if (!v) return null;
  const parts = v.split('|');
  if (Date.now() > Number(parts[1]) || !allowed(parts[0])) { props.deleteProperty('s:' + token); return null; }
  return parts[0];
}

// ---------- data (only the 4 dashboard-related tabs are read) ----------
function findBelow(sh, label, exact) {
  const v = sh.getDataRange().getDisplayValues(), L = label.toLowerCase();
  for (let r = 0; r < v.length; r++) for (let c = 0; c < v[r].length; c++) {
    const s = String(v[r][c]).trim().toLowerCase();
    if (exact ? s === L : s.indexOf(L) > -1) return v[r + 1] ? v[r + 1][c] : '';
  }
  return '';
}

function buildData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const today = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'), month = today.slice(0, 7);

  // daily coal data
  const dv = ss.getSheetByName('Coal Procure & Consump. Data').getDataRange().getValues();
  let hr = 0; for (; hr < 15; hr++) if (dv[hr].indexOf('Date') > -1) break;
  const H = dv[hr], iD = H.indexOf('Date'), iO = H.indexOf('Opening Stock (MT)'), iR = H.indexOf('Receive Stock (MT)'),
        iC = H.indexOf('Consumption (MT)'), iB = H.indexOf('Balance (MT)');
  const rows = [];
  for (let r = hr + 1; r < dv.length; r++) {
    const dt = dv[r][iD] instanceof Date ? dv[r][iD] : new Date(dv[r][iD]);
    if (isNaN(dt)) continue;
    const ds = Utilities.formatDate(dt, TZ, 'yyyy-MM-dd');
    if (ds > today) break;
    rows.push({ d: ds, o: num(dv[r][iO]), r: num(dv[r][iR]), c: num(dv[r][iC]), b: num(dv[r][iB]) });
  }
  const mrows = rows.filter(x => x.d.slice(0, 7) === month), last = rows[rows.length - 1] || { b: 0 };
  const sum = (a, k) => a.reduce((s, x) => s + x[k], 0);

  // inventory dashboard + monthwise summary
  const inv = ss.getSheetByName('Inventory Dashboard'), iv = inv.getDataRange().getDisplayValues();
  let jetty = 0;
  iv.forEach(row => { if (row.join('|').toLowerCase().indexOf('unloaded quantity from jetty') > -1)
    for (let c = row.length - 1; c >= 0; c--) if (/^[\d,]+(\.\d+)?$/.test(String(row[c]).trim())) { jetty = num(row[c]); break; } });
  const ms = ss.getSheetByName('Monthwise Summary');

  // supply dashboard
  const sh = ss.getSheetByName('Supply Dashboard'), sd = sh.getDataRange().getDisplayValues();
  const sec = { d: [], t: [], u: [] }, light = [];
  let cur = null, hdr = null, lh = null;
  sd.forEach(row => {
    const j = row.join('|').toLowerCase();
    if (/discharge ongoing/.test(j)) { cur = 'd'; hdr = null; return; }
    if (/towards bangladesh:/.test(j)) { cur = 't'; hdr = null; return; }
    if (/upcoming laycans \(not yet/.test(j)) { cur = 'u'; hdr = null; return; }
    if (/lighter status summary/.test(j)) { cur = 'l'; return; }
    if (cur === 'l') { if (row[0] === 'Sl') lh = row; else if (lh && /^\d+$/.test(row[0])) light.push(row); return; }
    if (!cur) return;
    if (row[0] === '#') { hdr = row; return; }
    if (hdr && /^\d+$/.test(row[0]) && row[1]) { const o = {}; hdr.forEach((h, i) => { if (h) o[h] = row[i]; }); sec[cur].push(o); }
  });
  const q = a => a.reduce((s, o) => s + num(o['Qty (MT)']), 0);
  const ships = lh ? lh.slice(3).filter(String) : [];

  return {
    asOf: Utilities.formatDate(new Date(), TZ, 'dd MMM yyyy, HH:mm'),
    inv: {
      open: mrows.length ? mrows[0].o : 0, recvM: sum(mrows, 'r'), consM: sum(mrows, 'c'), close: last.b,
      allR: sum(rows, 'r'), allC: sum(rows, 'c'),
      usable: num(findBelow(inv, 'usuable coal stock') || findBelow(inv, 'usable coal stock')),
      jetty: jetty, plf: findBelow(ms, 'MTD Plant Factor', true),
      days85: findBelow(ms, 'for 85% plant factor'), daysNow: findBelow(ms, 'present situation')
    },
    daily: rows.slice(-45),
    ves: { d: sec.d, t: sec.t, u: sec.u, qd: q(sec.d), qt: q(sec.t), qu: q(sec.u), next: findBelow(sh, 'next laycan starts', true) },
    lighters: { ships: ships, rows: light.map(r => ({ label: r[1], total: r[2], per: r.slice(3, 3 + ships.length) })) }
  };
}
